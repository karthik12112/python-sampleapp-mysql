# Sample Python App Connects to mysql

# Depoly App

sh wraper.sh
